import React, { useState } from 'react';
import { Bell, Plus, X } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { toast } from 'react-hot-toast';

interface Alert {
  id: string;
  symbol: string;
  price_target: number;
  condition: 'above' | 'below';
  active: boolean;
}

export const AlertsPanel: React.FC = () => {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [newAlert, setNewAlert] = useState({
    symbol: 'EUR/USD',
    price_target: 0,
    condition: 'above' as const,
  });

  const createAlert = async () => {
    try {
      const { data, error } = await supabase
        .from('price_alerts')
        .insert([
          {
            symbol: newAlert.symbol,
            price_target: newAlert.price_target,
            condition: newAlert.condition,
          },
        ])
        .select();

      if (error) throw error;

      setAlerts([...alerts, data[0]]);
      toast.success('Alert created successfully!');
    } catch (error) {
      toast.error('Failed to create alert');
    }
  };

  const deleteAlert = async (id: string) => {
    try {
      const { error } = await supabase
        .from('price_alerts')
        .delete()
        .match({ id });

      if (error) throw error;

      setAlerts(alerts.filter((alert) => alert.id !== id));
      toast.success('Alert deleted successfully!');
    } catch (error) {
      toast.error('Failed to delete alert');
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">Price Alerts</h2>
        <Bell className="h-5 w-5 text-gray-600" />
      </div>

      <div className="space-y-4">
        <div className="flex space-x-2">
          <select
            className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            value={newAlert.symbol}
            onChange={(e) =>
              setNewAlert({ ...newAlert, symbol: e.target.value })
            }
          >
            <option>EUR/USD</option>
            <option>GBP/USD</option>
            <option>USD/JPY</option>
            <option>AUD/USD</option>
            <option>USD/CAD</option>
            <option>USD/CHF</option>
          </select>
          <input
            type="number"
            step="0.00001"
            className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            placeholder="Price target"
            value={newAlert.price_target}
            onChange={(e) =>
              setNewAlert({
                ...newAlert,
                price_target: parseFloat(e.target.value),
              })
            }
          />
          <select
            className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            value={newAlert.condition}
            onChange={(e) =>
              setNewAlert({
                ...newAlert,
                condition: e.target.value as 'above' | 'below',
              })
            }
          >
            <option value="above">Above</option>
            <option value="below">Below</option>
          </select>
          <button
            onClick={createAlert}
            className="p-2 rounded-md bg-indigo-600 text-white hover:bg-indigo-700"
          >
            <Plus className="h-5 w-5" />
          </button>
        </div>

        {alerts.map((alert) => (
          <div
            key={alert.id}
            className="flex items-center justify-between p-3 border rounded-lg"
          >
            <div>
              <span className="font-medium">{alert.symbol}</span>
              <span className="ml-2 text-gray-600">
                {alert.condition} {alert.price_target}
              </span>
            </div>
            <button
              onClick={() => deleteAlert(alert.id)}
              className="p-1 rounded-full hover:bg-gray-100"
            >
              <X className="h-4 w-4 text-gray-600" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};