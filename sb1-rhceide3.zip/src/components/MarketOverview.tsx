import React from 'react';
import { ForexPair } from '../types';
import { ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';

interface MarketOverviewProps {
  pairs: ForexPair[];
  onPairSelect: (symbol: string) => void;
}

export const MarketOverview: React.FC<MarketOverviewProps> = ({ pairs, onPairSelect }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-4">
      <h2 className="text-xl font-semibold mb-4">Market Overview</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {pairs.map((pair) => (
          <div
            key={pair.symbol}
            className="border rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
            onClick={() => onPairSelect(pair.symbol)}
          >
            <div className="flex justify-between items-center">
              <span className="font-semibold">{pair.symbol.replace('frx', '')}</span>
              {pair.change > 0 ? (
                <ArrowUpRight className="text-green-500" />
              ) : pair.change < 0 ? (
                <ArrowDownRight className="text-red-500" />
              ) : (
                <Minus className="text-gray-500" />
              )}
            </div>
            <div className="mt-2 space-y-1">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Price:</span>
                <span>{pair.bid.toFixed(5)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Change:</span>
                <span className={pair.change > 0 ? 'text-green-500' : 'text-red-500'}>
                  {pair.change > 0 ? '+' : ''}{pair.change.toFixed(2)}%
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};