import React from 'react';
import { TimeframeSignal } from '../types';
import { TrendingUp, TrendingDown, Minus, Target } from 'lucide-react';

interface SignalPanelProps {
  signals: TimeframeSignal[];
}

export const SignalPanel: React.FC<SignalPanelProps> = ({ signals }) => {
  const getSignalIcon = (signal: 'buy' | 'sell' | 'neutral') => {
    switch (signal) {
      case 'buy':
        return <TrendingUp className="text-green-500" />;
      case 'sell':
        return <TrendingDown className="text-red-500" />;
      default:
        return <Minus className="text-gray-500" />;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-4">
      <h2 className="text-xl font-semibold mb-4">Trading Signals</h2>
      <div className="space-y-4">
        {signals.map((signal) => (
          <div
            key={signal.timeframe}
            className="border rounded-lg p-4 hover:shadow-md transition-shadow"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-3">
                {getSignalIcon(signal.signal)}
                <span className="font-medium">{signal.timeframe}</span>
              </div>
              <div className="flex items-center space-x-4">
                <span className={`font-semibold ${
                  signal.signal === 'buy' ? 'text-green-500' :
                  signal.signal === 'sell' ? 'text-red-500' :
                  'text-gray-500'
                }`}>
                  {signal.signal.toUpperCase()}
                </span>
                <span className="text-sm text-gray-500">
                  Strength: {signal.strength}%
                </span>
              </div>
            </div>

            {signal.signal !== 'neutral' && signal.entryPrice && (
              <div className="space-y-2 mt-2 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Entry Price:</span>
                  <span className="font-medium">{signal.entryPrice}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Stop Loss:</span>
                  <span className="font-medium text-red-500">{signal.stopLoss}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Take Profit:</span>
                  <span className="font-medium text-green-500">{signal.takeProfit}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Risk/Reward:</span>
                  <span className="font-medium">1:{signal.riskRewardRatio}</span>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};