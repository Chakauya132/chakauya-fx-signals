export interface ForexPair {
  symbol: string;
  bid: number;
  ask: number;
  change: number;
  signal: 'buy' | 'sell' | 'neutral';
}

export interface TimeframeSignal {
  timeframe: string;
  signal: 'buy' | 'sell' | 'neutral';
  strength: number;
  timestamp: string;
  stopLoss?: number;
  takeProfit?: number;
  entryPrice?: number;
  riskRewardRatio?: number;
}

export interface SignalIndicators {
  rsi: number;
  macd: {
    value: number;
    signal: number;
    histogram: number;
  };
  movingAverages: {
    ma20: number;
    ma50: number;
    ma200: number;
  };
}

export interface DerivTick {
  symbol: string;
  quote: number;
  epoch: number;
  pip_size: number;
}