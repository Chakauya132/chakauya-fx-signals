import { create } from 'zustand';
import { RSI, MACD, SMA, ATR } from 'technicalindicators';

const DERIV_APP_ID = 'WaYDBjuHJNY5PxU';
const DERIV_WS_URL = 'wss://ws.binaryws.com/websockets/v3';

interface ForexState {
  prices: Record<string, number>;
  connected: boolean;
  error: string | null;
  connect: () => void;
  disconnect: () => void;
  updatePrice: (instrument: string, price: number) => void;
}

export const useForexStore = create<ForexState>((set) => ({
  prices: {},
  connected: false,
  error: null,
  connect: () => {
    const ws = new WebSocket(DERIV_WS_URL);
    
    ws.onopen = () => {
      set({ connected: true, error: null });
      
      // Authenticate with Deriv
      ws.send(JSON.stringify({
        authorize: DERIV_APP_ID,
      }));

      // Subscribe to forex pairs
      const symbols = ['frxEURUSD', 'frxGBPUSD', 'frxUSDJPY', 'frxAUDUSD', 'frxUSDCAD', 'frxUSDCHF'];
      symbols.forEach(symbol => {
        ws.send(JSON.stringify({
          ticks: symbol,
          subscribe: 1
        }));
      });
    };
    
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      if (data.msg_type === 'authorize') {
        console.log('Successfully authenticated with Deriv');
      }
      
      if (data.msg_type === 'tick') {
        const symbol = data.tick.symbol.replace('frx', '');
        const price = data.tick.quote;
        
        set((state) => ({
          prices: {
            ...state.prices,
            [symbol]: price
          }
        }));
      }
    };
    
    ws.onerror = (error) => {
      set({ error: error.message });
      console.error('WebSocket error:', error);
    };
    
    ws.onclose = () => {
      set({ connected: false });
      console.log('WebSocket connection closed');
      
      setTimeout(() => {
        console.log('Attempting to reconnect...');
        set((state) => ({ ...state })).connect();
      }, 5000);
    };
  },
  disconnect: () => set({ connected: false }),
  updatePrice: (instrument, price) => 
    set((state) => ({
      prices: { ...state.prices, [instrument]: price }
    }))
}));

const calculateStopLossAndTakeProfit = (
  signal: 'buy' | 'sell' | 'neutral',
  currentPrice: number,
  atr: number,
  strength: number
) => {
  if (signal === 'neutral') return null;

  const atrMultiplier = 1.5;
  const stopLossDistance = atr * atrMultiplier;
  const riskRewardRatio = 1 + (strength / 100); // Adjust take profit based on signal strength

  const stopLoss = signal === 'buy' 
    ? currentPrice - stopLossDistance 
    : currentPrice + stopLossDistance;

  const takeProfit = signal === 'buy'
    ? currentPrice + (stopLossDistance * riskRewardRatio)
    : currentPrice - (stopLossDistance * riskRewardRatio);

  return {
    stopLoss: Number(stopLoss.toFixed(5)),
    takeProfit: Number(takeProfit.toFixed(5)),
    entryPrice: Number(currentPrice.toFixed(5)),
    riskRewardRatio: Number(riskRewardRatio.toFixed(2))
  };
};

export const generateSignals = (prices: number[], timeframe: string) => {
  const rsi = new RSI({ values: prices, period: 14 });
  const macd = new MACD({
    values: prices,
    fastPeriod: 12,
    slowPeriod: 26,
    signalPeriod: 9,
    SimpleMAOscillator: false,
    SimpleMASignal: false
  });
  const sma20 = new SMA({ values: prices, period: 20 });
  const sma50 = new SMA({ values: prices, period: 50 });
  const atr = new ATR({
    high: prices.map(p => p * 1.001), // Simulate high prices
    low: prices.map(p => p * 0.999),  // Simulate low prices
    close: prices,
    period: 14
  });

  const rsiValue = rsi.getResult();
  const macdValue = macd.getResult();
  const sma20Value = sma20.getResult();
  const sma50Value = sma50.getResult();
  const atrValue = atr.getResult();

  let signal: 'buy' | 'sell' | 'neutral' = 'neutral';
  let strength = 0;

  // RSI conditions
  if (rsiValue[rsiValue.length - 1] < 30) {
    signal = 'buy';
    strength += 30;
  } else if (rsiValue[rsiValue.length - 1] > 70) {
    signal = 'sell';
    strength += 30;
  }

  // MACD conditions
  if (macdValue[macdValue.length - 1].histogram > 0 && 
      macdValue[macdValue.length - 2].histogram <= 0) {
    if (signal === 'neutral') signal = 'buy';
    strength += 40;
  } else if (macdValue[macdValue.length - 1].histogram < 0 && 
             macdValue[macdValue.length - 2].histogram >= 0) {
    if (signal === 'neutral') signal = 'sell';
    strength += 40;
  }

  // Moving Average conditions
  if (sma20Value[sma20Value.length - 1] > sma50Value[sma50Value.length - 1]) {
    if (signal === 'buy') strength += 30;
    else if (signal === 'neutral') {
      signal = 'buy';
      strength += 30;
    }
  } else if (sma20Value[sma20Value.length - 1] < sma50Value[sma50Value.length - 1]) {
    if (signal === 'sell') strength += 30;
    else if (signal === 'neutral') {
      signal = 'sell';
      strength += 30;
    }
  }

  strength = Math.min(strength, 100);
  const currentPrice = prices[prices.length - 1];
  const lastAtr = atrValue[atrValue.length - 1];
  
  const levels = calculateStopLossAndTakeProfit(signal, currentPrice, lastAtr, strength);

  return {
    signal,
    strength,
    ...levels,
    indicators: {
      rsi: rsiValue[rsiValue.length - 1],
      macd: macdValue[macdValue.length - 1],
      sma: {
        ma20: sma20Value[sma20Value.length - 1],
        ma50: sma50Value[sma50Value.length - 1]
      }
    }
  };
};