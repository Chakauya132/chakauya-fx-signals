import React, { useState } from 'react';
import { Chart } from './components/Chart';
import { SignalPanel } from './components/SignalPanel';
import { MarketOverview } from './components/MarketOverview';
import { BarChart3, Bell, Settings } from 'lucide-react';

// Mock data - In a real application, this would come from an API
const mockPairs = [
  { symbol: 'EUR/USD', bid: 1.09234, ask: 1.09236, change: 0.12, signal: 'buy' },
  { symbol: 'GBP/USD', bid: 1.26543, ask: 1.26545, change: -0.08, signal: 'sell' },
  { symbol: 'USD/JPY', bid: 148.432, ask: 148.434, change: 0.05, signal: 'neutral' },
  { symbol: 'AUD/USD', bid: 0.65432, ask: 0.65434, change: -0.15, signal: 'sell' },
  { symbol: 'USD/CAD', bid: 1.35234, ask: 1.35236, change: 0.03, signal: 'buy' },
  { symbol: 'USD/CHF', bid: 0.89876, ask: 0.89878, change: -0.06, signal: 'neutral' },
] as const;

const mockSignals = [
  { timeframe: 'M5', signal: 'buy', strength: 75, timestamp: '2024-03-10T10:00:00Z' },
  { timeframe: 'M15', signal: 'buy', strength: 65, timestamp: '2024-03-10T10:00:00Z' },
  { timeframe: 'M30', signal: 'neutral', strength: 50, timestamp: '2024-03-10T10:00:00Z' },
  { timeframe: 'H1', signal: 'sell', strength: 70, timestamp: '2024-03-10T10:00:00Z' },
  { timeframe: 'H4', signal: 'sell', strength: 80, timestamp: '2024-03-10T10:00:00Z' },
  { timeframe: 'D1', signal: 'neutral', strength: 45, timestamp: '2024-03-10T10:00:00Z' },
] as const;

// Generate properly ordered chart data
const generateChartData = () => {
  const data = [];
  const now = new Date();
  
  for (let i = 0; i < 100; i++) {
    const date = new Date(now);
    date.setDate(date.getDate() - (99 - i));
    const dateStr = date.toISOString().split('T')[0];
    
    // Generate realistic price movements
    const basePrice = 1.0900;
    const volatility = 0.002;
    const open = basePrice + (Math.random() - 0.5) * volatility;
    const high = open + Math.random() * volatility;
    const low = open - Math.random() * volatility;
    const close = low + Math.random() * (high - low);
    
    data.push({
      time: dateStr,
      open: Number(open.toFixed(5)),
      high: Number(high.toFixed(5)),
      low: Number(low.toFixed(5)),
      close: Number(close.toFixed(5)),
    });
  }
  
  return data;
};

const mockChartData = generateChartData();

function App() {
  const [selectedPair, setSelectedPair] = useState('EUR/USD');

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <BarChart3 className="h-6 w-6 text-blue-600" />
              <h1 className="text-xl font-bold text-gray-900">ChakauyaFxSignals</h1>
            </div>
            <div className="flex items-center space-x-4">
              <button className="p-2 rounded-full hover:bg-gray-100">
                <Bell className="h-5 w-5 text-gray-600" />
              </button>
              <button className="p-2 rounded-full hover:bg-gray-100">
                <Settings className="h-5 w-5 text-gray-600" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-8">
            <Chart symbol={selectedPair} data={mockChartData} />
            <MarketOverview 
              pairs={mockPairs as any} 
              onPairSelect={setSelectedPair}
            />
          </div>

          {/* Right Column */}
          <div className="space-y-8">
            <SignalPanel signals={mockSignals as any} />
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;